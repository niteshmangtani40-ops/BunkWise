import { getAllAttendance, getAllSubjects, getAllTimetable, getProfile, markAttendance } from '../db.js';
import { today, getDatesInMonth, getDayIndex, calcPercentage, formatDateFull, getAttendanceStatus, getProgressClass, calcSafeBunks, calcClassesNeeded, formatDateShort, timeAgo } from '../utils.js';
import { showToast } from '../notifications.js';

let currentMonth = new Date();
let _calendarCache = null;
let _selectedDate = today();

export async function init() {
  try {
    bindEvents();
    setupLiveUpdates();
    setupSwipeNavigation();
    await loadCalendar();
  } catch (error) {
    console.error('[Calendar] Init failed:', error);
    showToast('Calendar could not load. Redirecting to dashboard.', 'error');
    setTimeout(() => { window.location.href = './dashboard.html'; }, 900);
  }
}
export async function refresh() {
    await loadCalendar();
}
async function loadCalendar() {
  const [subjects, attendance, timetable, profile] = await Promise.all([
    getAllSubjects(),
    getAllAttendance(),
    getAllTimetable(),
    getProfile(),
  ]);

  _calendarCache = { subjects, attendance, timetable, profile };

  renderMonthHeader(profile);
  renderStats(attendance);
  renderCalendarGrid(subjects, attendance, timetable);
}

function renderMonthHeader(profile) {
  const title = document.getElementById('calendar-title');
  const subtitle = document.getElementById('calendar-subtitle');
  if (title) title.textContent = currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  if (subtitle) subtitle.textContent = `${profile?.name || 'Student'} • ${profile?.college || 'My College'}`;
}

function renderStats(attendance) {
  const stats = { present: 0, absent: 0, cancelled: 0, holiday: 0 };
  attendance.forEach((record) => { if (stats[record.status] !== undefined) stats[record.status] += 1; });
  setText('cal-present', stats.present);
  setText('cal-absent', stats.absent);
  setText('cal-cancelled', stats.cancelled);
  setText('cal-holiday', stats.holiday);
}

function renderCalendarGrid(subjects, attendance, timetable) {
  const grid = document.getElementById('calendar-grid');
  if (!grid) return;

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();
  const days = getDatesInMonth(year, month);
  const firstDow = new Date(year, month, 1).getDay();
  const todayIso = today();
  const subjectMap = Object.fromEntries(subjects.map((subject) => [subject.id, subject]));
  const attendanceByDate = attendance.reduce((acc, record) => {
    (acc[record.date] ||= []).push(record);
    return acc;
  }, {});

  const fragment = document.createDocumentFragment();
  ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach((day) => {
    const head = document.createElement('div');
    head.className = 'calendar-day-head';
    head.textContent = day;
    fragment.appendChild(head);
  });

  for (let i = 0; i < firstDow; i += 1) {
    const blank = document.createElement('div');
    blank.className = 'calendar-day blank';
    fragment.appendChild(blank);
  }

  days.forEach((date) => {
    const dayEl = document.createElement('button');
    dayEl.type = 'button';
    dayEl.className = 'calendar-day';
    const records = attendanceByDate[date] || [];
    const present = records.filter((record) => record.status === 'present').length;
    const total = records.filter((record) => record.status === 'present' || record.status === 'absent').length;
    const pct = calcPercentage(present, total);
    const classes = timetable.filter((slot) => slot.day === getDayIndex(date));

    dayEl.innerHTML = `
      <div class="calendar-day-number">${Number(date.slice(-2))}</div>
      <div class="calendar-day-meta">${records.length ? `${pct}%` : `${classes.length} class${classes.length === 1 ? '' : 'es'}`}</div>
      <div class="calendar-dots">
        ${records.slice(0, 3).map((record) => `<span class="calendar-dot ${record.status}"></span>`).join('')}
      </div>
    `;

    if (date === todayIso) dayEl.classList.add('today');
    if (date === _selectedDate) dayEl.classList.add('selected');
    dayEl.addEventListener('click', () => renderDayDetails(date, records, subjectMap));
    fragment.appendChild(dayEl);
  });

  grid.innerHTML = '';
  grid.appendChild(fragment);

  if (days.includes(todayIso)) {
    renderDayDetails(todayIso, attendanceByDate[todayIso] || [], subjectMap);
  }
}

function renderDayDetails(date, records, subjectMap) {
  const container = document.getElementById('calendar-day-details');
  if (!container) return;
  _selectedDate = date;
  const dayLabel = formatDateFull(date);

  if (!records.length) {
    container.innerHTML = `
      <div class="empty-state" style="padding:var(--space-5)">
        <div class="empty-state-icon"><i class="fa-solid fa-calendar-day"></i></div>
        <h3>${dayLabel}</h3>
        <p>No attendance records for this day.</p>
        <button class="btn btn-primary btn-sm" id="calendar-add-record">Add Attendance</button>
      </div>
    `;
    document.getElementById('calendar-add-record')?.addEventListener('click', () => window.location.href = `./attendance.html?date=${date}`);
    return;
  }

  const stats = buildDayStats(records);
  container.innerHTML = `
    <div style="font-weight:700;font-size:16px;margin-bottom:var(--space-3)">${dayLabel}</div>
    <div class="grid grid-4" style="gap:var(--space-3);margin-bottom:var(--space-4)">
      <div class="dash-stat-card"><div class="dash-stat-value">${stats.present}</div><div class="dash-stat-label">Present</div></div>
      <div class="dash-stat-card"><div class="dash-stat-value">${stats.absent}</div><div class="dash-stat-label">Absent</div></div>
      <div class="dash-stat-card"><div class="dash-stat-value">${stats.cancelled}</div><div class="dash-stat-label">Cancelled</div></div>
      <div class="dash-stat-card"><div class="dash-stat-value">${stats.totalPct}%</div><div class="dash-stat-label">Attendance</div></div>
    </div>
    <div class="stagger-children">
      ${records.map((record) => {
        const subject = subjectMap[record.subjectId];
        const status = getAttendanceStatus(record.status === 'present' ? 100 : record.status === 'absent' ? 0 : 50);
        return `
          <div class="card" style="padding:var(--space-3);margin-bottom:var(--space-3)">
            <div style="display:flex;justify-content:space-between;gap:var(--space-3)">
              <div>
                <div style="font-weight:700">${escapeHtml(subject?.name || 'Unknown subject')}</div>
                <div style="font-size:13px;color:var(--text-secondary)">${escapeHtml(subject?.faculty || 'Faculty not set')}</div>
                <div style="font-size:12px;color:var(--text-tertiary);margin-top:4px">${escapeHtml(subject?.room || 'No room set')}</div>
              </div>
              <div style="font-weight:700;text-transform:capitalize;color:${status.color}">${record.status}</div>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-top:var(--space-3);gap:var(--space-3)">
              <div style="font-size:12px;color:var(--text-tertiary)">${timeAgo(record.markedAt || record.date)}</div>
              <button class="btn btn-ghost btn-sm" data-edit-record="${record.subjectId}">Edit</button>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;

  container.querySelectorAll('[data-edit-record]').forEach((button) => {
    button.addEventListener('click', async (event) => {
      const subjectId = Number(event.currentTarget.dataset.editRecord);
      const nextStatus = await promptStatus(records.find((r) => r.subjectId === subjectId)?.status || 'present');
      if (!nextStatus) return;
      await markAttendance(subjectId, date, nextStatus);
      await loadCalendar();
      window.dispatchEvent(new CustomEvent('bunkwise:data-changed', { detail: { source: 'attendance', date } }));
    });
  });
}

function bindEvents() {
  document.getElementById('cal-prev')?.addEventListener('click', () => {
    currentMonth.setMonth(currentMonth.getMonth() - 1);
    loadCalendar();
  });
  document.getElementById('cal-next')?.addEventListener('click', () => {
    currentMonth.setMonth(currentMonth.getMonth() + 1);
    loadCalendar();
  });
  document.getElementById('cal-today')?.addEventListener('click', () => {
    currentMonth = new Date();
    loadCalendar();
  });
}

function setupLiveUpdates() {
  window.addEventListener('bunkwise:data-changed', (event) => {
    if (['attendance', 'subjects', 'timetable', 'profile', 'reset'].includes(event.detail?.source)) {
      loadCalendar();
    }
  });
}

function setupSwipeNavigation() {
  const container = document.getElementById('calendar-grid');
  if (!container) return;
  let startX = 0;
  let startY = 0;

  container.addEventListener('touchstart', (event) => {
    const touch = event.touches?.[0];
    if (!touch) return;
    startX = touch.clientX;
    startY = touch.clientY;
  }, { passive: true });

  container.addEventListener('touchend', (event) => {
    const touch = event.changedTouches?.[0];
    if (!touch) return;
    const diffX = touch.clientX - startX;
    const diffY = Math.abs(touch.clientY - startY);
    if (diffY > 60) return;

    if (diffX < -60) {
      document.getElementById('cal-next')?.click();
    } else if (diffX > 60) {
      document.getElementById('cal-prev')?.click();
    }
  }, { passive: true });
}

function buildDayStats(records) {
  const present = records.filter((record) => record.status === 'present').length;
  const absent = records.filter((record) => record.status === 'absent').length;
  const cancelled = records.filter((record) => record.status === 'cancelled').length;
  const total = present + absent;
  return {
    present,
    absent,
    cancelled,
    totalPct: calcPercentage(present, total),
  };
}

async function promptStatus(current) {
  const next = window.prompt(`Enter attendance status for this record (present, absent, cancelled, holiday)`, current);
  if (!next) return null;
  const normalized = String(next).trim().toLowerCase();
  return ['present', 'absent', 'cancelled', 'holiday'].includes(normalized) ? normalized : null;
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function escapeHtml(value = '') {
  const div = document.createElement('div');
  div.textContent = String(value);
  return div.innerHTML;
}